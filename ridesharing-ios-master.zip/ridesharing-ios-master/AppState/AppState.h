#import <Foundation/Foundation.h>

//! Project version number for AppState.
FOUNDATION_EXPORT double AppStateVersionNumber;

//! Project version string for AppState.
FOUNDATION_EXPORT const unsigned char AppStateVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AppState/PublicHeader.h>


