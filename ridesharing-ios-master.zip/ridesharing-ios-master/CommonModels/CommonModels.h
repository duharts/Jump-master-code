//
//  CommonModels.h
//  CommonModels
//
//  Created by Dmytro Shapovalov on 20.11.2019.
//  Copyright © 2019 Dmytro Shapovalov. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for CommonModels.
FOUNDATION_EXPORT double CommonModelsVersionNumber;

//! Project version string for CommonModels.
FOUNDATION_EXPORT const unsigned char CommonModelsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CommonModels/PublicHeader.h>


