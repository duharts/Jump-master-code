//
//  CommonViews.h
//  CommonViews
//
//  Created by Dmytro Shapovalov on 20.11.2019.
//  Copyright © 2019 Dmytro Shapovalov. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for CommonViews.
FOUNDATION_EXPORT double CommonViewsVersionNumber;

//! Project version string for CommonViews.
FOUNDATION_EXPORT const unsigned char CommonViewsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CommonViews/PublicHeader.h>


